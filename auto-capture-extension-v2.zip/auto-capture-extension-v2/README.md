# 📸 Auto Page Capture — Chrome Extension

> **Automatically screenshot every page, slide, or scroll position as you browse** — hands-free, zero effort.

![Version](https://img.shields.io/badge/version-1.1.0-6c63ff?style=flat-square)
![Manifest V3](https://img.shields.io/badge/Manifest-V3-22c55e?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-blue?style=flat-square)
![Browsers](https://img.shields.io/badge/browsers-Chrome%20%7C%20Edge%20%7C%20Firefox-orange?style=flat-square)

---

## 🎯 What It Does

Auto Page Capture is a browser extension that **automatically takes screenshots** whenever something changes on your screen — a new slide loads, you stop scrolling, the URL changes, or simply on a timer.

Perfect for:
- 📚 Capturing every page of an online ebook or PDF reader
- 🎞️ Recording each slide of a web-based presentation (Google Slides, Reveal.js, Keynote Web)
- 🗂️ Archiving multi-page web articles
- 📝 Building visual notes while researching
- 🎓 Recording lecture slides automatically

---

## ✨ Features

| Feature | Details |
|--------|---------|
| 🖱️ **Scroll Stop Mode** | Captures after you pause scrolling — great for reading |
| 🎞️ **Slide Change Mode** | Detects arrow keys, PageDown, or next/prev button clicks |
| 🔗 **URL Change Mode** | Captures on every page navigation |
| ⏱️ **Auto Timer Mode** | Captures every N seconds automatically |
| 📷 **Manual Capture** | Instant one-click screenshot anytime |
| 🚫 **Duplicate Detection** | Skips identical pages using perceptual hashing |
| 🖼️ **PNG / JPEG** | Choose format — PNG for quality, JPEG for smaller files |
| 📁 **Custom Folder** | Screenshots saved to `Downloads/YourFolderName/` |
| 🔔 **Notifications** | Optional desktop notification on each capture |
| 📋 **Activity Log** | Live log of all captures in the popup |

---

## 🔧 Installation

### Chrome / Microsoft Edge

1. **Download** the ZIP and extract it to a folder on your PC
2. Open Chrome and go to: `chrome://extensions/`  
   (Edge: `edge://extensions/`)
3. Enable **Developer Mode** (toggle in top-right)
4. Click **"Load unpacked"**
5. Select the `auto-capture-extension` folder
6. The 📸 icon appears in your toolbar — you're ready!

> ✅ Works on **Chrome 88+** and **Edge 88+** (Manifest V3 supported)

### Firefox

1. Open Firefox and go to: `about:debugging#/runtime/this-firefox`
2. Click **"Load Temporary Add-on…"**
3. Navigate into the extension folder and select `manifest.json`

> ⚠️ Firefox temporary add-ons are removed on browser restart. For permanent install, the extension would need to be submitted to Mozilla Add-ons.

---

## 🚀 How to Use

### Step 1 — Open the popup
Click the 📸 icon in the browser toolbar.

### Step 2 — Choose your Detection Mode

```
🖱️ Scroll Stop   — Best for reading long pages, ebooks, articles
🎞️ Slide Change  — Best for presentations, Kindle reader, slide decks
🔗 URL Change    — Best for navigating multi-page sites
⏱️ Auto Timer    — Best for videos, live dashboards, or timed content
```

### Step 3 — Configure settings

- **Save folder**: Name of the sub-folder inside your `Downloads/` directory
- **Timer interval**: Seconds between auto-captures (Timer mode only)
- **Image format**: PNG (lossless) or JPEG (smaller file size)
- **Skip duplicates**: Automatically skip if the page looks the same
- **Show notifications**: Get a desktop pop-up on each capture

### Step 4 — Press ▶ Start

Screenshots will begin saving automatically to:
```
C:\Users\YourName\Downloads\PageCaptures\
```

---

## 📁 File Naming

Each screenshot is saved with a sequential index and timestamp:

```
PageCaptures/
  capture_0001_20250305_143022.png
  capture_0002_20250305_143045.png
  capture_0003_20250305_143101.png
  ...
```

---

## ⚙️ Technical Architecture

```
auto-capture-extension/
├── manifest.json       ← Extension config (Manifest V3)
├── background.js       ← Service Worker: capture logic, alarm timer, URL watcher
├── content.js          ← Injected: detects scroll, keyboard, DOM changes
├── popup.html          ← Extension popup UI
├── popup.js            ← Popup logic, state management, settings
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

### How Each Mode Works Internally

| Mode | Mechanism |
|------|-----------|
| Scroll Stop | `content.js` listens for `scroll` events; fires after 1.2s of no scroll activity |
| Slide Change | `content.js` monitors keydown events + click on nav buttons + DOM mutations |
| URL Change | `background.js` uses `chrome.tabs.onUpdated` API |
| Timer | `background.js` uses `chrome.alarms` API (survives service worker sleep) |

---

## 🐛 Bug Fixes in v1.1.0

| Bug | Fix Applied |
|-----|-------------|
| Timer mode stopping after ~30 seconds | Replaced `setInterval` with `chrome.alarms` API |
| State lost after browser sleep | Persists all state to `chrome.storage.local` |
| Crash on empty notification ID | Proper unique IDs like `cap_0001` |
| Extension errors in iframes | Added `chrome.runtime.id` guard in `content.js` |
| Missing `notifications` permission | Added to `manifest.json` |
| Missing `alarms` permission | Added to `manifest.json` |

---

## ⚠️ Known Limitations

- **Cannot capture `chrome://` pages** — browser security restriction (applies to all extensions)
- **Requires "Allow access to file URLs"** disabled by default — enable in `chrome://extensions` if you want to capture local HTML files
- **Downloads folder only** — Chrome extensions cannot save directly to `Pictures\Screenshots` due to sandboxing; move files manually if desired
- **DRM-protected pages** (like Amazon Kindle Web Reader) — screenshots may be blank due to canvas protection

---

## 🔐 Permissions Explained

| Permission | Why It's Needed |
|-----------|----------------|
| `tabs` | Read tab URL and take screenshots |
| `activeTab` | Access the currently focused tab |
| `downloads` | Save screenshots to Downloads folder |
| `scripting` | Inject content.js to detect scroll/slide events |
| `storage` | Save settings and capture state |
| `alarms` | Reliable timer that survives service worker suspension |
| `notifications` | Show desktop notification when screenshot is saved |

---

## 🛣️ Roadmap / Future Ideas

- [ ] ZIP export — download all captures as a single archive
- [ ] Cloud sync — upload screenshots to Google Drive / Dropbox
- [ ] Page counter overlay — stamp each image with page number
- [ ] Crop region — select only a portion of the screen
- [ ] Keyboard shortcut — configurable hotkey to start/stop
- [ ] Chrome Web Store release

---

## 👨‍💻 Author

**Prof. (Dr.) Ajay Shriram Kushwaha**  
Department of Computer Science & Applications  
Sharda School of Computing Science & Engineering, Sharda University  
🌐 [ajaykushwaha.in](https://ajaykushwaha.in)

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

## 🙏 Contributing

Pull requests are welcome! If you find a bug or want to suggest a feature:
1. Fork the repo
2. Create a feature branch: `git checkout -b feature/your-idea`
3. Commit your changes: `git commit -m 'Add your feature'`
4. Push: `git push origin feature/your-idea`
5. Open a Pull Request

---

*Made with ❤️ for researchers, students, and anyone who reads too many slides.*
