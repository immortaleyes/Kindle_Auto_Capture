// background.js — Service Worker for Auto Page Capture (v1.1.0 Fixed)
// KEY FIXES:
//  • Uses chrome.alarms instead of setInterval (MV3 SWs get suspended)
//  • Persists all state to chrome.storage.local (survives SW sleep/wake)
//  • Proper notification ID (no empty string)
//  • State rehydration on SW restart

const ALARM_NAME = 'auto-capture-timer';

// In-memory cache (rehydrated from storage on each SW wake)
let _state = null;

async function getState() {
  if (_state) return _state;
  const data = await chrome.storage.local.get('bgState');
  _state = data.bgState || {
    running: false,
    paused: false,
    mode: 'scroll',
    settings: {},
    lastHash: null,
    lastUrl: null,
    captureIndex: 0
  };
  return _state;
}

async function saveState() {
  if (_state) await chrome.storage.local.set({ bgState: _state });
}

// Message Router
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg).then(() => sendResponse({ ok: true })).catch(err => {
    console.error('[AutoCapture]', err);
    sendResponse({ ok: false, error: err.message });
  });
  return true;
});

async function handleMessage(msg) {
  const state = await getState();

  switch (msg.type) {
    case 'START':
      state.running  = true;
      state.paused   = false;
      state.mode     = msg.mode || 'scroll';
      state.settings = msg.settings || {};
      await saveState();
      await startMode(state);
      break;

    case 'PAUSE':
      state.paused = true;
      await saveState();
      await chrome.alarms.clear(ALARM_NAME);
      break;

    case 'RESUME':
      state.paused = false;
      await saveState();
      if (state.mode === 'timer') await startAlarm(state);
      break;

    case 'STOP':
      state.running = false;
      state.paused  = false;
      await saveState();
      await chrome.alarms.clear(ALARM_NAME);
      break;

    case 'SET_MODE':
      state.mode = msg.mode;
      await saveState();
      if (state.running && !state.paused) {
        await chrome.alarms.clear(ALARM_NAME);
        await startMode(state);
      }
      break;

    case 'MANUAL_CAPTURE':
      if (msg.settings) state.settings = msg.settings;
      await saveState();
      await doCapture('manual');
      break;

    case 'CONTENT_SCROLL_STOP':
      if (state.running && !state.paused && state.mode === 'scroll') {
        await doCapture('scroll');
      }
      break;

    case 'CONTENT_SLIDE_CHANGE':
      if (state.running && !state.paused && state.mode === 'slide') {
        await doCapture('slide');
      }
      break;
  }
}

// Alarm handler (replaces setInterval)
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;
  const state = await getState();
  if (state.running && !state.paused && state.mode === 'timer') {
    await doCapture('timer');
  }
});

// URL/navigation monitoring
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const state = await getState();
  if (!state.running || state.paused || state.mode !== 'url') return;
  if (changeInfo.status === 'complete' && tab.url) {
    if (tab.url !== state.lastUrl && !tab.url.startsWith('chrome://')) {
      state.lastUrl = tab.url;
      await saveState();
      setTimeout(() => doCapture('url-change', tabId), 900);
    }
  }
});

async function startMode(state) {
  await chrome.alarms.clear(ALARM_NAME);
  if (state.mode === 'timer') await startAlarm(state);
  sendLog('Mode started: ' + getModeLabel(state.mode));
}

async function startAlarm(state) {
  const sec = parseInt(state.settings.timerInterval) || 5;
  await chrome.alarms.create(ALARM_NAME, {
    delayInMinutes: sec / 60,
    periodInMinutes: sec / 60
  });
}

async function doCapture(trigger, specificTabId) {
  const state = await getState();
  try {
    let tabs;
    if (specificTabId) {
      const allTabs = await chrome.tabs.query({ currentWindow: true });
      tabs = allTabs.filter(t => t.id === specificTabId);
    } else {
      tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    }

    if (!tabs || tabs.length === 0) return;
    const tab = tabs[0];
    if (!tab.id || !tab.url) return;
    if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') ||
        tab.url.startsWith('about:') || tab.url.startsWith('edge://')) return;

    const format = (state.settings.imgFormat === 'jpeg') ? 'jpeg' : 'png';
    let dataUrl;
    try {
      dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format,
        quality: format === 'jpeg' ? 90 : undefined
      });
    } catch (e) {
      sendLog('Capture blocked: ' + e.message, 'warn');
      return;
    }

    if (state.settings.skipDupe) {
      const hash = quickHash(dataUrl);
      if (hash === state.lastHash) {
        sendLog('Skipped — duplicate page', 'info');
        return;
      }
      state.lastHash = hash;
    }

    state.captureIndex = (state.captureIndex || 0) + 1;
    await saveState();

    const ts     = getTimestamp();
    const idx    = String(state.captureIndex).padStart(4, '0');
    const folder = sanitize(state.settings.folderName || 'PageCaptures');
    const fname  = folder + '/capture_' + idx + '_' + ts + '.' + format;

    await chrome.downloads.download({
      url: dataUrl,
      filename: fname,
      conflictAction: 'uniquify',
      saveAs: false
    });

    chrome.runtime.sendMessage({ type: 'CAPTURED', filename: fname }).catch(() => {});

    if (state.settings.showNotif) {
      try {
        await chrome.notifications.create('cap_' + idx, {
          type: 'basic',
          iconUrl: 'icons/icon48.png',
          title: 'Page Captured',
          message: 'Saved: capture_' + idx + '.' + format
        });
      } catch(e) {}
    }

  } catch (err) {
    sendLog('Error: ' + err.message, 'warn');
  }
}

function getTimestamp() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return d.getFullYear() + pad(d.getMonth()+1) + pad(d.getDate()) + '_' +
         pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
}

function sanitize(str) {
  return (str || 'PageCaptures').replace(/[^a-zA-Z0-9_\-]/g, '_');
}

function quickHash(str) {
  const sample = str.slice(0, 500) + str.slice(-500) + str.length;
  let hash = 0;
  for (let i = 0; i < sample.length; i++) {
    hash = ((hash << 5) - hash) + sample.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}

function getModeLabel(mode) {
  const labels = { scroll: 'Scroll Stop', slide: 'Slide Change', url: 'URL Change', timer: 'Auto Timer' };
  return labels[mode] || mode;
}

function sendLog(text, level) {
  chrome.runtime.sendMessage({ type: 'LOG', text: text, level: level || 'info' }).catch(() => {});
}
