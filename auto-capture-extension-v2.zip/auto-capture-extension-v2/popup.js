// popup.js — UI controller for Auto Page Capture extension

let state = {
  running: false,
  paused: false,
  mode: 'scroll',
  captureCount: 0,
  logs: []
};

// --- DOM refs ---
const btnStart  = document.getElementById('btnStart');
const btnPause  = document.getElementById('btnPause');
const btnStop   = document.getElementById('btnStop');
const btnSnap   = document.getElementById('btnSnap');
const statusDot  = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const captureCount = document.getElementById('captureCount');
const logBox    = document.getElementById('logBox');
const clearLog  = document.getElementById('clearLog');
const folderName  = document.getElementById('folderName');
const folderDisplay = document.getElementById('folderDisplay');
const timerInterval = document.getElementById('timerInterval');
const imgFormat   = document.getElementById('imgFormat');
const showNotif   = document.getElementById('showNotif');
const skipDupe    = document.getElementById('skipDupe');

// --- Init: load saved state ---
chrome.storage.local.get(['captureState', 'settings'], (data) => {
  if (data.settings) {
    folderName.value = data.settings.folderName || 'PageCaptures';
    timerInterval.value = data.settings.timerInterval || 5;
    imgFormat.value = data.settings.imgFormat || 'png';
    showNotif.checked = data.settings.showNotif !== false;
    skipDupe.checked = data.settings.skipDupe !== false;
    folderDisplay.textContent = folderName.value;

    if (data.settings.mode) {
      state.mode = data.settings.mode;
      updateModeButtons(state.mode);
    }
  }

  if (data.captureState) {
    state.running = data.captureState.running || false;
    state.paused  = data.captureState.paused  || false;
    state.captureCount = data.captureState.count || 0;
    state.logs = data.captureState.logs || [];
    updateUI();
    renderLogs();
  }
});

// --- Mode buttons ---
document.querySelectorAll('.mode-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    state.mode = btn.dataset.mode;
    updateModeButtons(state.mode);
    saveSettings();
    sendToBackground({ type: 'SET_MODE', mode: state.mode });
    addLog(`Mode changed → ${getModeLabel(state.mode)}`, 'info');
  });
});

function updateModeButtons(mode) {
  document.querySelectorAll('.mode-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.mode === mode);
  });
}

function getModeLabel(mode) {
  return { scroll: 'Scroll Stop', slide: 'Slide Change', url: 'URL Change', timer: 'Auto Timer' }[mode] || mode;
}

// --- Folder name live update ---
folderName.addEventListener('input', () => {
  folderDisplay.textContent = folderName.value || 'PageCaptures';
  saveSettings();
});

[timerInterval, imgFormat, showNotif, skipDupe].forEach(el => {
  el.addEventListener('change', saveSettings);
});

function saveSettings() {
  chrome.storage.local.set({
    settings: {
      folderName: folderName.value,
      timerInterval: parseInt(timerInterval.value) || 5,
      imgFormat: imgFormat.value,
      showNotif: showNotif.checked,
      skipDupe: skipDupe.checked,
      mode: state.mode
    }
  });
}

// --- Buttons ---
btnStart.addEventListener('click', () => {
  saveSettings();
  state.running = true;
  state.paused  = false;
  updateUI();
  sendToBackground({ type: 'START', mode: state.mode, settings: getSettings() });
  addLog(`▶ Started — mode: ${getModeLabel(state.mode)}`, 'success');
});

btnPause.addEventListener('click', () => {
  state.paused = !state.paused;
  updateUI();
  sendToBackground({ type: state.paused ? 'PAUSE' : 'RESUME' });
  addLog(state.paused ? '⏸ Paused' : '▶ Resumed', 'info');
});

btnStop.addEventListener('click', () => {
  state.running = false;
  state.paused  = false;
  updateUI();
  sendToBackground({ type: 'STOP' });
  addLog('■ Stopped', 'warn');
});

btnSnap.addEventListener('click', () => {
  sendToBackground({ type: 'MANUAL_CAPTURE', settings: getSettings() });
  addLog('📷 Manual capture triggered', 'info');
});

clearLog.addEventListener('click', () => {
  state.logs = [];
  logBox.innerHTML = '<div class="log-entry info">Log cleared.</div>';
  saveCapState();
});

// --- Listen for messages from background ---
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'CAPTURED') {
    state.captureCount++;
    captureCount.textContent = `${state.captureCount} saved`;
    addLog(`✅ Saved: ${msg.filename}`, 'success');
    saveCapState();
  }
  if (msg.type === 'LOG') {
    addLog(msg.text, msg.level || 'info');
  }
});

// --- Helpers ---
function getSettings() {
  return {
    folderName: folderName.value || 'PageCaptures',
    timerInterval: parseInt(timerInterval.value) || 5,
    imgFormat: imgFormat.value,
    showNotif: showNotif.checked,
    skipDupe: skipDupe.checked
  };
}

function sendToBackground(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {});
}

function updateUI() {
  btnStart.disabled = state.running;
  btnPause.disabled = !state.running;
  btnStop.disabled  = !state.running;

  btnPause.textContent = state.paused ? '▶ Resume' : '⏸ Pause';

  statusDot.className = 'status-dot' +
    (state.running && !state.paused ? ' active' :
     state.paused ? ' paused' : '');

  statusText.innerHTML = state.running && !state.paused
    ? `<strong>Capturing</strong> — ${getModeLabel(state.mode)}`
    : state.paused
    ? `<strong>Paused</strong>`
    : `Idle — not capturing`;

  captureCount.textContent = `${state.captureCount} saved`;
  saveCapState();
}

function addLog(text, level = '') {
  const now = new Date();
  const time = now.toLocaleTimeString('en-US', { hour12: false });
  const entry = { text: `[${time}] ${text}`, level };
  state.logs.push(entry);
  if (state.logs.length > 50) state.logs.shift();

  const div = document.createElement('div');
  div.className = `log-entry ${level}`;
  div.textContent = entry.text;
  logBox.appendChild(div);
  logBox.scrollTop = logBox.scrollHeight;
}

function renderLogs() {
  logBox.innerHTML = '';
  (state.logs || []).forEach(e => {
    const div = document.createElement('div');
    div.className = `log-entry ${e.level || ''}`;
    div.textContent = e.text;
    logBox.appendChild(div);
  });
  logBox.scrollTop = logBox.scrollHeight;
}

function saveCapState() {
  chrome.storage.local.set({
    captureState: { running: state.running, paused: state.paused, count: state.captureCount, logs: state.logs }
  });
}
