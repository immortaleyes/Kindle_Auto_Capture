// content.js — Injected into every page (v1.1.0 Fixed)
// FIX: Guard against frames where chrome.runtime may be unavailable

(function () {
  // Guard: only run in top-level frames with runtime access
  if (window !== window.top) return;
  if (typeof chrome === 'undefined' || !chrome.runtime) return;
  if (window.__autoCaptureInjected) return;
  window.__autoCaptureInjected = true;

  function safeSend(msg) {
    try {
      if (chrome.runtime && chrome.runtime.id) {
        chrome.runtime.sendMessage(msg).catch(() => {});
      }
    } catch (e) {}
  }

  // ─── Scroll Stop Detection ────────────────────────────────────────────────
  let scrollTimer = null;
  let lastScrollY = window.scrollY;

  window.addEventListener('scroll', () => {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => {
      const delta = Math.abs(window.scrollY - lastScrollY);
      if (delta > 80) {
        lastScrollY = window.scrollY;
        safeSend({ type: 'CONTENT_SCROLL_STOP' });
      }
    }, 1200);
  }, { passive: true });

  // ─── Keyboard Navigation (Slides) ────────────────────────────────────────
  let lastKeyCapture = 0;

  document.addEventListener('keydown', (e) => {
    const slideKeys = ['ArrowRight', 'ArrowLeft', 'ArrowDown', 'ArrowUp',
                       'PageDown', 'PageUp', ' ', 'Enter'];
    if (!slideKeys.includes(e.key)) return;
    const now = Date.now();
    if (now - lastKeyCapture < 800) return;
    lastKeyCapture = now;
    setTimeout(() => safeSend({ type: 'CONTENT_SLIDE_CHANGE' }), 400);
  });

  // ─── Click-based Slide Navigation ────────────────────────────────────────
  let lastClickCapture = 0;

  document.addEventListener('click', (e) => {
    const target = e.target.closest('button, a, [role="button"]') || e.target;
    const text = (target.textContent || '').toLowerCase().trim().slice(0, 20);
    const aria = (target.getAttribute('aria-label') || '').toLowerCase();
    const cls  = (target.className || '').toString().toLowerCase();

    const isNav =
      /^(next|prev|previous|forward|back|›|‹|→|←|▶|◀)$/.test(text) ||
      /next|prev|forward|back|slide.?nav|carousel.?btn/.test(aria) ||
      /next.?btn|prev.?btn|slide.?arrow|carousel.?control/.test(cls);

    if (!isNav) return;
    const now = Date.now();
    if (now - lastClickCapture < 800) return;
    lastClickCapture = now;
    setTimeout(() => safeSend({ type: 'CONTENT_SLIDE_CHANGE' }), 500);
  });

  // ─── DOM Mutation (SPA / JS slides like Reveal.js, Google Slides) ────────
  let mutTimer = null;
  let mutCount = 0;

  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.addedNodes.length + m.removedNodes.length > 0) mutCount++;
    }
    clearTimeout(mutTimer);
    mutTimer = setTimeout(() => {
      if (mutCount >= 3) safeSend({ type: 'CONTENT_SLIDE_CHANGE' });
      mutCount = 0;
    }, 600);
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: false,
    characterData: false
  });

})();
