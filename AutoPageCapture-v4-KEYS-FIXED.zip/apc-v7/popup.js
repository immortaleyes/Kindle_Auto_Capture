// popup.js v3.0
let session = 0;

const togBtn   = document.getElementById('togBtn');
const capBtn   = document.getElementById('capBtn');
const testBtn  = document.getElementById('testBtn');
const totalN   = document.getElementById('totalN');
const sessionN = document.getElementById('sessionN');
const logBox   = document.getElementById('logBox');
const clearLog = document.getElementById('clearLog');

// ── Init ──────────────────────────────────────────────────────────────────────
chrome.runtime.sendMessage({ type: 'GET_STATE' }, resp => {
  void chrome.runtime.lastError;
  if (resp) { setToggle(resp.enabled); totalN.textContent = resp.captureIndex || 0; }
});

chrome.storage.local.get(['logs'], d => {
  if (d.logs && d.logs.length) {
    logBox.innerHTML = '';
    d.logs.slice(-30).forEach(e => addLine(e.t, e.v, false));
  }
});

// ── Toggle ────────────────────────────────────────────────────────────────────
togBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'TOGGLE' }, resp => {
    void chrome.runtime.lastError;
    if (resp) setToggle(resp.enabled);
  });
});

// ── Manual capture ────────────────────────────────────────────────────────────
capBtn.addEventListener('click', () => {
  capBtn.textContent = '⏳...';
  capBtn.disabled = true;

  // We need to capture the active tab — inject a trigger via scripting API
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    void chrome.runtime.lastError;
    if (!tabs || !tabs[0]) {
      addLine('No active tab found', 'w');
      capBtn.textContent = '📷 Capture Now'; capBtn.disabled = false;
      return;
    }
    const tab = tabs[0];
    // Inject content script trigger directly
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        try {
          chrome.runtime.sendMessage({ type: 'TRIGGER', trigger: 'manual' }, () => void chrome.runtime.lastError);
        } catch(e) {}
      }
    }, () => {
      void chrome.runtime.lastError;
      capBtn.textContent = '📷 Capture Now'; capBtn.disabled = false;
    });
  });
});

// ── Run diagnostic test ───────────────────────────────────────────────────────
testBtn.addEventListener('click', () => {
  testBtn.disabled = true;
  testBtn.textContent = '⏳ Testing...';
  addLine('--- Running test ---', 'i');

  chrome.tabs.query({ active: true, currentWindow: true }, async tabs => {
    void chrome.runtime.lastError;

    if (!tabs || !tabs[0]) {
      addLine('FAIL: No active tab', 'w');
      testBtn.disabled = false; testBtn.textContent = '🔍 Run Test';
      return;
    }

    const tab = tabs[0];
    addLine('Tab: ' + tab.url.slice(0,55), 'i');

    // Test captureVisibleTab
    try {
      const data = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 30 });
      addLine('✅ Screenshot OK (' + Math.round(data.length/1024) + 'KB)', 's');

      // Test download — flat filename first (most permissive)
      try {
        const dlId = await chrome.downloads.download({
          url: data,
          filename: 'TEST_AutoSave_' + Date.now() + '.jpg',
          saveAs: false,
          conflictAction: 'uniquify'
        });
        addLine('✅ Download started! ID=' + dlId, 's');
        addLine('Check Downloads folder for TEST_AutoSave_*.jpg', 's');

        // Now test with subfolder
        try {
          const dlId2 = await chrome.downloads.download({
            url: data,
            filename: 'AutoSave/TEST_subfolder_' + Date.now() + '.jpg',
            saveAs: false,
            conflictAction: 'uniquify'
          });
          addLine('✅ Subfolder OK! AutoSave/ folder created. ID=' + dlId2, 's');
        } catch(sfErr) {
          addLine('⚠ Subfolder blocked: ' + sfErr.message, 'w');
          addLine('Fix: Chrome Settings → Downloads → OFF "Ask where to save"', 'w');
        }
      } catch(dlErr) {
        addLine('❌ Download FAILED: ' + dlErr.message, 'w');
        addLine('→ Go to chrome://settings/downloads', 'w');
        addLine('→ Turn OFF "Ask where to save each file"', 'w');
      }
    } catch(capErr) {
      addLine('❌ Screenshot FAILED: ' + capErr.message, 'w');
    }

    testBtn.disabled = false;
    testBtn.textContent = '🔍 Run Test';
  });
});

// ── Clear log ─────────────────────────────────────────────────────────────────
clearLog.addEventListener('click', () => {
  logBox.innerHTML = '<div class="le i">Log cleared.</div>';
  chrome.storage.local.set({ logs: [] });
});

// ── Listen from background ────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'CAPTURED') {
    session++;
    sessionN.textContent = session;
    totalN.textContent   = msg.captureIndex || 0;
    addLine('✅ #' + msg.idx + ' saved (' + msg.trigger + ')', 's');
  }
  if (msg.type === 'STATE') {
    setToggle(msg.enabled);
    totalN.textContent = msg.captureIndex || 0;
  }
  if (msg.type === 'LOG') addLine(msg.text, msg.level);
});

// ── Helpers ───────────────────────────────────────────────────────────────────
function setToggle(on) {
  togBtn.className = 'tog ' + (on ? 'on' : 'off');
  togBtn.innerHTML = on
    ? '✅ &nbsp;CAPTURING IS ON — Click to Pause'
    : '❌ &nbsp;CAPTURING IS OFF — Click to Enable';
}

function addLine(text, cls, save = true) {
  const t = new Date().toLocaleTimeString('en',{hour12:false});
  const d = document.createElement('div');
  d.className = 'le ' + (cls||'');
  d.textContent = '[' + t + '] ' + text;
  logBox.appendChild(d);
  logBox.scrollTop = logBox.scrollHeight;
  if (save) {
    chrome.storage.local.get(['logs'], r => {
      const logs = ((r.logs)||[]).slice(-49);
      logs.push({ t: '['+t+'] '+text, v: cls||'' });
      chrome.storage.local.set({ logs });
    });
  }
}


// ── Re-inject into all tabs ───────────────────────────────────────────────────
var injectBtn = document.getElementById('injectBtn');
if (injectBtn) {
  injectBtn.addEventListener('click', function() {
    injectBtn.textContent = '⏳ Injecting...';
    injectBtn.disabled = true;
    chrome.runtime.sendMessage({ type: 'INJECT_ALL' }, function() {
      void chrome.runtime.lastError;
      addLine('⚡ Content script injected into all open tabs', 'i');
      addLine('Now press P on any Chrome tab — it should work!', 's');
      injectBtn.textContent = '⚡ Re-inject into All Open Tabs (fix P key / scroll)';
      injectBtn.disabled = false;
    });
  });
}
