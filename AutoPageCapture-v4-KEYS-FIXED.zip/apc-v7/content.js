// content.js v4.0 — injected programmatically into every tab
// Guards against double-injection

(function () {
  if (window.__apc_injected) return;
  window.__apc_injected = true;

  // ── Safe send to background ───────────────────────────────────────────────
  function send(trigger) {
    try {
      chrome.runtime.sendMessage({ type: 'TRIGGER', trigger: trigger }, function() {
        void chrome.runtime.lastError; // suppress unchecked error
      });
    } catch(e) {}
  }

  // ── Visual toast feedback ─────────────────────────────────────────────────
  function toast(msg) {
    var old = document.getElementById('__apc_toast');
    if (old) old.remove();
    var el = document.createElement('div');
    el.id = '__apc_toast';
    el.textContent = msg;
    el.setAttribute('style', [
      'position:fixed', 'bottom:20px', 'right:20px', 'z-index:2147483647',
      'background:rgba(22,163,74,0.95)', 'color:#fff',
      'padding:10px 20px', 'border-radius:10px',
      'font:700 13px/1.4 -apple-system,system-ui,sans-serif',
      'box-shadow:0 4px 20px rgba(0,0,0,0.3)',
      'transition:opacity 0.5s ease', 'pointer-events:none'
    ].join(';'));
    document.documentElement.appendChild(el);
    setTimeout(function(){ el.style.opacity = '0'; }, 1600);
    setTimeout(function(){ if(el.parentNode) el.remove(); }, 2200);
  }

  // ── Is user typing in a field? ────────────────────────────────────────────
  function isTyping() {
    var el = document.activeElement;
    if (!el) return false;
    var t = el.tagName;
    return t==='INPUT' || t==='TEXTAREA' || t==='SELECT' ||
           el.isContentEditable === true ||
           el.getAttribute('role') === 'textbox';
  }

  // ─────────────────────────────────────────────────────────────────────────
  // TRIGGER 1: P key — capture NOW
  // ─────────────────────────────────────────────────────────────────────────
  window.addEventListener('keydown', function(e) {
    if (e.key !== 'p' && e.key !== 'P') return;
    if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;
    if (isTyping()) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    toast('📸 Saving...');
    send('keyP');
  }, true);

  // ─────────────────────────────────────────────────────────────────────────
  // TRIGGER 2: Scroll stop (80px+ movement, 1.2s debounce)
  // ─────────────────────────────────────────────────────────────────────────
  var scrollTimer = null;
  var baseY = window.scrollY;
  var baseX = window.scrollX;

  window.addEventListener('scroll', function() {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(function() {
      var dy = Math.abs(window.scrollY - baseY);
      var dx = Math.abs(window.scrollX - baseX);
      if (dy >= 80 || dx >= 80) {
        baseY = window.scrollY;
        baseX = window.scrollX;
        toast('📸 Scroll saved');
        send('scroll');
      }
    }, 1200);
  }, { passive: true });

  // ─────────────────────────────────────────────────────────────────────────
  // TRIGGER 3: Arrow / Page keys (slide navigation)
  // ─────────────────────────────────────────────────────────────────────────
  var slideKeys = { ArrowLeft:1, ArrowRight:1, ArrowUp:1, ArrowDown:1, PageUp:1, PageDown:1 };
  var slideTimer = null;

  window.addEventListener('keydown', function(e) {
    if (!slideKeys[e.key]) return;
    if (isTyping()) return;
    clearTimeout(slideTimer);
    slideTimer = setTimeout(function() {
      toast('📸 Slide saved');
      send('slide');
    }, 600);
  }, { passive: true });

  // Confirm injection to background
  send('CONTENT_READY');

})();
