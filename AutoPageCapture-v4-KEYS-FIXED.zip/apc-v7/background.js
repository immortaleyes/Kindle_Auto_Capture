// ============================================================
//  Auto Page Capture v4.0 — background.js
//
//  FIX: Programmatically injects content.js into ALL open tabs
//       on install, update, and every new tab that loads.
//       Static content_scripts in manifest miss already-open tabs.
// ============================================================

const FOLDER     = 'AutoSave';
const MIN_GAP_MS = 1500;

let isEnabled    = true;
let captureIndex = 0;
let lastHash     = 0;
let lastCapMs    = 0;

// ── On install / update: inject into ALL existing open tabs ──────────────────
chrome.runtime.onInstalled.addListener(() => {
  injectIntoAllTabs();
});

// ── On browser startup: inject into all tabs again ───────────────────────────
chrome.runtime.onStartup.addListener(() => {
  injectIntoAllTabs();
});

// ── When a tab finishes loading: inject content script ───────────────────────
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (!tab.url) return;
  if (isInternalUrl(tab.url)) return;
  injectTab(tabId);
});

// ── When user switches to a tab: re-inject if needed ─────────────────────────
chrome.tabs.onActivated.addListener((info) => {
  chrome.tabs.get(info.tabId, (tab) => {
    if (chrome.runtime.lastError) return;
    if (!tab || !tab.url || isInternalUrl(tab.url)) return;
    injectTab(info.tabId);
  });
});

// ── Inject content.js into one tab ───────────────────────────────────────────
function injectTab(tabId) {
  chrome.scripting.executeScript({
    target: { tabId: tabId, allFrames: false },
    files: ['content.js']
  }).catch(() => {}); // silently ignore errors (e.g. extension pages)
}

// ── Inject into ALL currently open tabs ──────────────────────────────────────
function injectIntoAllTabs() {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (!tab.id || !tab.url || isInternalUrl(tab.url)) continue;
      injectTab(tab.id);
    }
  });
}

// ── Restore state from storage on SW wake ────────────────────────────────────
(async () => {
  const d = await chrome.storage.local.get(['enabled', 'capIdx', 'lastHash']);
  isEnabled    = (d.enabled !== false);
  captureIndex = (d.capIdx  || 0);
  lastHash     = (d.lastHash || 0);
  setBadge();
})();

function persist() {
  chrome.storage.local.set({ enabled: isEnabled, capIdx: captureIndex, lastHash: lastHash });
}

function setBadge() {
  chrome.action.setBadgeText({ text: isEnabled ? '' : 'OFF' });
  chrome.action.setBadgeBackgroundColor({ color: isEnabled ? '#22c55e' : '#ef4444' });
}

// ── Message listener ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // Content script is ready in a tab
  if (msg.type === 'CONTENT_READY') {
    sendResponse({ ok: true });
    return true;
  }

  // Capture trigger from content script
  if (msg.type === 'TRIGGER') {
    if (!isEnabled) { sendResponse({ ok: true, skipped: true }); return true; }
    const tab = (sender && sender.tab) ? sender.tab : null;
    doCapture(msg.trigger, tab)
      .then(() => sendResponse({ ok: true }))
      .catch(e => { notify('❌ Capture Error', e.message); sendResponse({ ok: false }); });
    return true;
  }

  if (msg.type === 'TOGGLE') {
    isEnabled = !isEnabled;
    persist(); setBadge();
    // Tell all content scripts
    chrome.tabs.query({}, tabs => {
      tabs.forEach(t => {
        if (!t.id || !t.url || isInternalUrl(t.url)) return;
        chrome.tabs.sendMessage(t.id, { type: 'ENABLED', value: isEnabled }).catch(() => {});
      });
    });
    sendResponse({ ok: true, enabled: isEnabled });
    return true;
  }

  if (msg.type === 'GET_STATE') {
    sendResponse({ enabled: isEnabled, captureIndex: captureIndex });
    return true;
  }

  if (msg.type === 'INJECT_ALL') {
    injectIntoAllTabs();
    sendResponse({ ok: true });
    return true;
  }
});

// ── Core capture ─────────────────────────────────────────────────────────────
async function doCapture(trigger, senderTab) {
  const now = Date.now();
  if (now - lastCapMs < MIN_GAP_MS) return;
  lastCapMs = now;

  // Use sender tab (always correct since content.js sent it)
  let tab = senderTab;

  // Fallback if no sender tab (e.g. from popup manual button)
  if (!tab || !tab.id) {
    const wins = await chrome.windows.getAll({ windowTypes: ['normal'] });
    if (!wins.length) return notify('❌ No Window', 'No browser window found');
    const win = wins.find(w => w.focused) || wins[wins.length - 1];
    const tabs = await chrome.tabs.query({ active: true, windowId: win.id });
    tab = tabs[0];
  }

  if (!tab || !tab.id) return notify('❌ No Tab', 'Could not find tab');
  if (!tab.url || isInternalUrl(tab.url)) return;

  // Screenshot
  let dataUrl;
  try {
    dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  } catch (e) {
    return notify('❌ Capture Failed', e.message);
  }
  if (!dataUrl || dataUrl.length < 200) return notify('❌ Empty', 'Screenshot was empty');

  // Dedup
  const hash = simpleHash(dataUrl.slice(-3000));
  if (hash === lastHash) return;
  lastHash = hash;
  persist();

  // Filename
  captureIndex++;
  persist();
  const idx   = String(captureIndex).padStart(4, '0');
  const fname = FOLDER + '/capture_' + idx + '_' + trigger + '_' + ts() + '.png';

  // Download — try subfolder first, flat fallback
  let saved = false;
  try {
    const id = await chrome.downloads.download({ url: dataUrl, filename: fname, saveAs: false, conflictAction: 'uniquify' });
    if (id >= 0) saved = true;
  } catch (e) {
    try {
      const id2 = await chrome.downloads.download({ url: dataUrl, filename: 'AutoSave_' + idx + '_' + trigger + '_' + ts() + '.png', saveAs: false, conflictAction: 'uniquify' });
      if (id2 >= 0) { saved = true; notify('📸 Saved #' + idx, 'Saved flat (AutoSave subfolder blocked)\nFix: chrome://settings/downloads → OFF "Ask where to save"'); }
    } catch (e2) {
      return notify('❌ Save Failed', 'Turn OFF "Ask where to save" in Chrome Downloads settings');
    }
  }

  if (!saved) return notify('❌ No Download ID', 'Check Chrome → Settings → Downloads → Ask where to save = OFF');

  notify('📸 Saved! #' + idx, 'Downloads/AutoSave/' + 'capture_' + idx + '.png\nTrigger: ' + trigger);

  chrome.runtime.sendMessage({ type: 'CAPTURED', idx: idx, trigger: trigger, captureIndex: captureIndex }).catch(() => {});

  // Flash badge
  chrome.action.setBadgeText({ text: idx });
  setTimeout(() => setBadge(), 2500);
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function isInternalUrl(url) {
  return !url || ['chrome://', 'chrome-extension://', 'edge://', 'about:', 'devtools://', 'moz-extension://'].some(p => url.startsWith(p));
}

function ts() {
  const d = new Date(), p = n => String(n).padStart(2,'0');
  return d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'_'+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds());
}

function simpleHash(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h) ^ s.charCodeAt(i);
  return h >>> 0;
}

function notify(title, msg) {
  try {
    chrome.notifications.create('apc_' + Date.now(), {
      type: 'basic', iconUrl: 'icons/icon48.png',
      title: title, message: msg || '', priority: 2
    });
  } catch(e) {}
}
