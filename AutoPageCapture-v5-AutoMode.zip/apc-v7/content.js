// content.js v5.0 — Auto-capture all pages mode + manual P/scroll triggers

(function () {
  if (window.__apc_injected) return;
  window.__apc_injected = true;

  var autoTimer   = null;   // interval handle for auto mode
  var autoRunning = false;
  var slideDelay  = 1800;   // ms to wait after arrow key before capturing

  // ── Safe send ───────────────────────────────────────────────────────────────
  function send(type, data) {
    try {
      var msg = Object.assign({ type: type }, data || {});
      chrome.runtime.sendMessage(msg, function() { void chrome.runtime.lastError; });
    } catch(e) {}
  }

  // ── Is user typing? ─────────────────────────────────────────────────────────
  function isTyping() {
    var el = document.activeElement;
    if (!el) return false;
    var t = el.tagName;
    return t==='INPUT'||t==='TEXTAREA'||t==='SELECT'||
           el.isContentEditable||el.getAttribute('role')==='textbox';
  }

  // ── Press the right arrow key on the page (simulates reader navigation) ────
  function pressRight() {
    // Try clicking Kindle's native next button first
    var nextBtn = document.querySelector(
      '[class*="next"],[class*="Next"],[aria-label*="next"],[aria-label*="Next"],' +
      '[class*="forward"],[class*="Forward"],[id*="next"],[id*="next-page"],' +
      '.kg-next-page, .kcrPage, [data-action="next"]'
    );
    if (nextBtn) {
      nextBtn.click();
      return;
    }
    // Fallback: dispatch real keyboard events on document
    ['keydown','keypress','keyup'].forEach(function(evType) {
      var ev = new KeyboardEvent(evType, {
        key: 'ArrowRight', code: 'ArrowRight', keyCode: 39,
        which: 39, bubbles: true, cancelable: true
      });
      document.dispatchEvent(ev);
    });
    // Also try clicking the right half of the page (Kindle tap-to-advance)
    try {
      var el = document.elementFromPoint(window.innerWidth * 0.75, window.innerHeight * 0.5);
      if (el && el !== document.body) el.click();
    } catch(e) {}
  }

  // ── AUTO MODE: advance pages automatically until end ────────────────────────
  function startAuto(delay) {
    if (autoRunning) return;
    autoRunning = true;
    slideDelay  = delay || 1800;

    send('AUTO_STATUS', { running: true, msg: 'Auto-capture started' });

    function step() {
      if (!autoRunning) return;
      pressRight();
      // Wait for page transition, then trigger capture
      setTimeout(function() {
        if (!autoRunning) return;
        send('TRIGGER', { trigger: 'auto' });
        // Schedule next step after capture debounce + buffer
        autoTimer = setTimeout(step, slideDelay + 800);
      }, slideDelay);
    }

    // Capture current page first, then start advancing
    send('TRIGGER', { trigger: 'auto_start' });
    setTimeout(step, 1200);
  }

  function stopAuto() {
    autoRunning = false;
    clearTimeout(autoTimer);
    send('AUTO_STATUS', { running: false, msg: 'Auto-capture stopped' });
  }

  // ── Listen for commands from background / popup ──────────────────────────────
  chrome.runtime.onMessage.addListener(function(msg) {
    if (msg.type === 'START_AUTO') startAuto(msg.delay);
    if (msg.type === 'STOP_AUTO')  stopAuto();
    if (msg.type === 'GET_AUTO_STATUS') send('AUTO_STATUS', { running: autoRunning });
  });

  // ── MANUAL: P key ───────────────────────────────────────────────────────────
  window.addEventListener('keydown', function(e) {
    if ((e.key !== 'p' && e.key !== 'P') || e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;
    if (isTyping()) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    send('TRIGGER', { trigger: 'keyP' });
  }, true);

  // ── MANUAL: Scroll stop ─────────────────────────────────────────────────────
  var scrollTimer = null, baseY = window.scrollY, baseX = window.scrollX;
  window.addEventListener('scroll', function() {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(function() {
      if (Math.abs(window.scrollY-baseY)>=80 || Math.abs(window.scrollX-baseX)>=80) {
        baseY = window.scrollY; baseX = window.scrollX;
        send('TRIGGER', { trigger: 'scroll' });
      }
    }, 1200);
  }, { passive: true });

  // ── MANUAL: Arrow / Page keys ───────────────────────────────────────────────
  var SLIDE_KEYS = {ArrowLeft:1,ArrowRight:1,ArrowUp:1,ArrowDown:1,PageUp:1,PageDown:1};
  var slideTimer = null;
  window.addEventListener('keydown', function(e) {
    if (!SLIDE_KEYS[e.key] || isTyping() || autoRunning) return; // skip if auto is running
    clearTimeout(slideTimer);
    slideTimer = setTimeout(function() { send('TRIGGER', { trigger: 'slide' }); }, 1200);
  }, { passive: true });

  send('CONTENT_READY', {});
})();
