// popup.js v5.0

let session = 0, skipped = 0, isAutoRunning = false;
let totalPages = 0; // for progress if known

const autoBtn     = document.getElementById('autoBtn');
const autoStatus  = document.getElementById('autoStatus');
const delaySlider = document.getElementById('delaySlider');
const delayVal    = document.getElementById('delayVal');
const injectBtn   = document.getElementById('injectBtn');
const progressWrap= document.getElementById('progressWrap');
const progCount   = document.getElementById('progCount');
const progFill    = document.getElementById('progFill');
const capBtn      = document.getElementById('capBtn');
const testBtn     = document.getElementById('testBtn');
const togBtn      = document.getElementById('togBtn');
const totalN      = document.getElementById('totalN');
const sessionN    = document.getElementById('sessionN');
const dupeN       = document.getElementById('dupeN');
const logBox      = document.getElementById('logBox');
const clearLog    = document.getElementById('clearLog');

// ── Init ──────────────────────────────────────────────────────────────────────
chrome.runtime.sendMessage({ type: 'GET_STATE' }, resp => {
  void chrome.runtime.lastError;
  if (!resp) return;
  setToggleUI(resp.enabled);
  totalN.textContent = resp.captureIndex || 0;
  if (resp.autoRunning) setAutoUI(true);
});

chrome.storage.local.get(['logs'], d => {
  if (d.logs?.length) {
    logBox.innerHTML = '';
    d.logs.slice(-30).forEach(e => addLine(e.t, e.v, false));
  }
});

// ── Delay slider ──────────────────────────────────────────────────────────────
delaySlider.addEventListener('input', () => {
  delayVal.textContent = parseFloat(delaySlider.value).toFixed(1) + 's';
});

// ── AUTO START / STOP ─────────────────────────────────────────────────────────
autoBtn.addEventListener('click', () => {
  if (isAutoRunning) {
    // Stop
    chrome.runtime.sendMessage({ type: 'STOP_AUTO' }, resp => {
      void chrome.runtime.lastError;
      setAutoUI(false);
      addLine('⏹ Auto-capture stopped', 'w');
    });
  } else {
    // Start
    const delay = Math.round(parseFloat(delaySlider.value) * 1000);
    chrome.runtime.sendMessage({ type: 'START_AUTO', delay }, resp => {
      void chrome.runtime.lastError;
      if (resp?.ok) {
        setAutoUI(true);
        session = 0; skipped = 0;
        sessionN.textContent = 0; dupeN.textContent = 0;
        addLine('▶ Auto-capture started (delay: ' + delaySlider.value + 's)', 'i');
        addLine('📖 Sit back — pages will advance automatically', 'i');
        addLine('🛑 Will stop when end of book is detected', 'i');
      } else {
        addLine('❌ Failed to start — try clicking ⚡ Re-inject first', 'w');
      }
    });
  }
});

// ── Re-inject ─────────────────────────────────────────────────────────────────
injectBtn.addEventListener('click', () => {
  injectBtn.disabled = true;
  injectBtn.textContent = '⏳...';
  chrome.runtime.sendMessage({ type: 'INJECT_ALL' }, () => {
    void chrome.runtime.lastError;
    setTimeout(() => {
      injectBtn.disabled = false;
      injectBtn.textContent = '⚡ Re-inject';
      addLine('⚡ Re-injected into all tabs', 'i');
    }, 1000);
  });
});

// ── Manual capture ────────────────────────────────────────────────────────────
capBtn.addEventListener('click', () => {
  capBtn.disabled = true; capBtn.textContent = '⏳...';
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    void chrome.runtime.lastError;
    if (!tabs?.[0]) { capBtn.disabled=false; capBtn.textContent='📷 Capture Now'; return; }
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => { try { chrome.runtime.sendMessage({ type:'TRIGGER', trigger:'manual' }, ()=>void chrome.runtime.lastError); } catch(e){} }
    }, () => { void chrome.runtime.lastError; capBtn.disabled=false; capBtn.textContent='📷 Capture Now'; });
  });
});

// ── Test ──────────────────────────────────────────────────────────────────────
testBtn.addEventListener('click', () => {
  testBtn.disabled = true; testBtn.textContent = '⏳';
  addLine('--- Test starting ---', 'i');
  chrome.tabs.query({ active: true, currentWindow: true }, async tabs => {
    void chrome.runtime.lastError;
    if (!tabs?.[0]) { addLine('No active tab', 'w'); testBtn.disabled=false; testBtn.textContent='🔍 Test'; return; }
    const tab = tabs[0];
    addLine('Tab: ' + tab.url.slice(0,50), 'i');
    try {
      const data = await chrome.tabs.captureVisibleTab(tab.windowId, { format:'jpeg', quality:20 });
      addLine('✅ Screenshot OK (' + Math.round(data.length/1024) + 'KB)', 's');
      const id = await chrome.downloads.download({ url:data, filename:'TEST_'+Date.now()+'.jpg', saveAs:false });
      addLine('✅ Download OK! ID=' + id + ' — check Downloads folder', 's');
      try {
        const id2 = await chrome.downloads.download({ url:data, filename:'AutoSave/TEST_'+Date.now()+'.jpg', saveAs:false });
        addLine('✅ AutoSave subfolder OK! All systems go.', 's');
      } catch(e) {
        addLine('⚠ Subfolder blocked: ' + e.message, 'w');
        addLine('Fix: chrome://settings/downloads → OFF "Ask where to save"', 'w');
      }
    } catch(e) {
      addLine('❌ ' + e.message, 'w');
    }
    testBtn.disabled=false; testBtn.textContent='🔍 Test';
  });
});

// ── Toggle ────────────────────────────────────────────────────────────────────
togBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type:'TOGGLE' }, resp => {
    void chrome.runtime.lastError;
    if (resp) setToggleUI(resp.enabled);
  });
});

// ── Clear log ─────────────────────────────────────────────────────────────────
clearLog.addEventListener('click', () => {
  logBox.innerHTML = '<div class="le i">Log cleared.</div>';
  chrome.storage.local.set({ logs: [] });
});

// ── Messages from background ──────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'CAPTURED') {
    session++;
    sessionN.textContent = session;
    totalN.textContent   = msg.captureIndex || 0;
    if (msg.autoRunning) {
      progCount.textContent = msg.captureIndex + ' pages saved';
      // Animate progress bar (we know max is ~205 for Kindle but use fill heuristic)
      const pct = Math.min(98, (session / 210) * 100);
      progFill.style.width = pct + '%';
    }
    addLine('✅ #' + msg.idx + ' saved [' + msg.trigger + ']', 's');
  }

  if (msg.type === 'STATE') {
    setToggleUI(msg.enabled);
    totalN.textContent = msg.captureIndex || 0;
    if (!msg.autoRunning && isAutoRunning) {
      // Auto stopped (end of book)
      setAutoUI(false);
      addLine('📚 Auto-capture finished! End of book detected.', 's');
      addLine('Total saved: ' + msg.captureIndex + ' pages', 's');
      progFill.style.width = '100%';
      progCount.textContent = msg.captureIndex + ' pages — DONE ✓';
    }
  }

  if (msg.type === 'AUTO_STATUS_UPDATE') {
    autoStatus.textContent = msg.running ? '🟡 Running' : '⚪ Idle';
  }

  if (msg.type === 'LOG') addLine(msg.text, msg.level);
});

// ── Helpers ───────────────────────────────────────────────────────────────────
function setAutoUI(running) {
  isAutoRunning = running;
  autoBtn.className = 'btn-auto-start' + (running ? ' running' : '');
  autoBtn.textContent = running ? '⏹ Stop Auto-Capture' : '▶ Start Auto-Capture';
  autoStatus.textContent = running ? '🟡 Running...' : '⚪ Idle';
  progressWrap.className = 'progress-wrap' + (running ? ' show' : '');
  delaySlider.disabled = running;
}

function setToggleUI(on) {
  togBtn.className = 'tog ' + (on ? 'on' : 'off');
  togBtn.innerHTML = on
    ? '✅ Capturing is ON — click to pause'
    : '❌ Capturing OFF — click to enable';
}

function addLine(text, cls, save=true) {
  const t = new Date().toLocaleTimeString('en',{hour12:false});
  const d = document.createElement('div');
  d.className = 'le ' + (cls||'');
  d.textContent = '['+t+'] '+text;
  logBox.appendChild(d);
  logBox.scrollTop = logBox.scrollHeight;
  if (save) {
    chrome.storage.local.get(['logs'], r => {
      const logs = (r.logs||[]).slice(-49);
      logs.push({ t:'['+t+'] '+text, v:cls||'' });
      chrome.storage.local.set({ logs });
    });
  }
}
