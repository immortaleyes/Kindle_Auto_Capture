// ============================================================
//  Auto Page Capture v5.0 — background.js
//  AUTO MODE: advances pages automatically, stops on duplicate
// ============================================================

const FOLDER      = 'AutoSave';
const MIN_GAP_MS  = 800;
const MAX_DUPES   = 3;   // stop after 3 identical frames (end of book)

let isEnabled     = true;
let captureIndex  = 0;
let lastHash      = 0;
let lastCapMs     = 0;
let autoRunning   = false;
let dupeStreak    = 0;    // consecutive identical captures

// ── Restore state on SW wake ─────────────────────────────────────────────────
(async () => {
  const d = await chrome.storage.local.get(['enabled','capIdx','lastHash']);
  isEnabled    = d.enabled !== false;
  captureIndex = d.capIdx  || 0;
  lastHash     = d.lastHash || 0;
  setBadge();
})();

function persist() {
  chrome.storage.local.set({ enabled: isEnabled, capIdx: captureIndex, lastHash });
}

function setBadge() {
  if (autoRunning) {
    chrome.action.setBadgeText({ text: 'AUTO' });
    chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
  } else if (isEnabled) {
    chrome.action.setBadgeText({ text: '' });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
  } else {
    chrome.action.setBadgeText({ text: 'OFF' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
  }
}

// ── Tab injection ─────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => injectAll());
chrome.runtime.onStartup.addListener(() => injectAll());

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url || isInternal(tab.url)) return;
  injectTab(tabId);
});

chrome.tabs.onActivated.addListener(info => {
  chrome.tabs.get(info.tabId, tab => {
    if (chrome.runtime.lastError || !tab?.url || isInternal(tab.url)) return;
    injectTab(info.tabId);
  });
});

function injectTab(tabId) {
  chrome.scripting.executeScript({ target: { tabId, allFrames: false }, files: ['content.js'] }).catch(() => {});
}

function injectAll() {
  chrome.tabs.query({}, tabs => {
    tabs.forEach(t => { if (t.id && t.url && !isInternal(t.url)) injectTab(t.id); });
  });
}

// ── Message listener ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === 'CONTENT_READY') {
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'TRIGGER') {
    if (!isEnabled) { sendResponse({ ok: true }); return true; }
    const tab = sender?.tab || null;
    doCapture(msg.trigger, tab)
      .then(result => sendResponse({ ok: true, result }))
      .catch(e => sendResponse({ ok: false, err: e.message }));
    return true;
  }

  if (msg.type === 'AUTO_STATUS') {
    // Relay status from content script to popup
    chrome.runtime.sendMessage({ type: 'AUTO_STATUS_UPDATE', ...msg }).catch(() => {});
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'START_AUTO') {
    autoRunning = true;
    dupeStreak  = 0;
    lastHash    = 0;  // reset so first page always captures
    setBadge();
    // Forward to content script in active tab
    getActiveTab().then(tab => {
      if (!tab) return sendResponse({ ok: false, err: 'No tab' });
      chrome.tabs.sendMessage(tab.id, { type: 'START_AUTO', delay: msg.delay || 1800 }).catch(() => {});
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'STOP_AUTO') {
    autoRunning = false;
    dupeStreak  = 0;
    setBadge();
    getActiveTab().then(tab => {
      if (tab) chrome.tabs.sendMessage(tab.id, { type: 'STOP_AUTO' }).catch(() => {});
    });
    notify('⏹ Auto-Capture Stopped', captureIndex + ' pages saved to Downloads/AutoSave/');
    broadcastState();
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'TOGGLE') {
    isEnabled = !isEnabled;
    persist(); setBadge(); broadcastState();
    sendResponse({ ok: true, enabled: isEnabled });
    return true;
  }

  if (msg.type === 'GET_STATE') {
    sendResponse({ enabled: isEnabled, captureIndex, autoRunning });
    return true;
  }

  if (msg.type === 'INJECT_ALL') {
    injectAll();
    sendResponse({ ok: true });
    return true;
  }
});

// ── Core capture ──────────────────────────────────────────────────────────────
async function doCapture(trigger, senderTab) {
  const now = Date.now();
  if (now - lastCapMs < MIN_GAP_MS) return 'debounced';
  lastCapMs = now;

  let tab = senderTab;
  if (!tab?.id) {
    tab = await getActiveTab();
  }
  if (!tab?.id) return notify('❌ No Tab', 'Cannot find browser tab');
  if (!tab.url || isInternal(tab.url)) return;

  // Hide overlays before screenshot
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const s = document.createElement('style');
        s.id = '__apc_hide';
        s.textContent = `
          [style*="position: fixed"],[style*="position:fixed"],
          [class*="toast"],[class*="Toast"],[class*="notification"],
          [class*="Notification"],[class*="overlay"],[class*="saved"],
          [class*="Saved"],[class*="badge"],[class*="snackbar"],
          [class*="Banner"],[role="status"],[role="alert"],
          [aria-live="polite"],[aria-live="assertive"]
          { opacity:0!important; visibility:hidden!important; }`;
        document.documentElement.appendChild(s);
      }
    });
  } catch(_) {}

  await sleep(100);

  // Screenshot
  let dataUrl;
  try {
    dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  } catch(e) {
    notify('❌ Capture Failed', e.message);
    return;
  }

  // Restore overlays
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => { const s = document.getElementById('__apc_hide'); if(s) s.remove(); }
  }).catch(() => {});

  if (!dataUrl || dataUrl.length < 200) return;

  // Duplicate / end-of-book detection
  const hash = simpleHash(dataUrl.slice(-4000));
  if (hash === lastHash) {
    dupeStreak++;
    if (autoRunning && dupeStreak >= MAX_DUPES) {
      // End of book reached!
      autoRunning = false;
      setBadge();
      // Stop content script
      chrome.tabs.sendMessage(tab.id, { type: 'STOP_AUTO' }).catch(() => {});
      notify('📚 Book Complete!', `All pages saved!\nTotal: ${captureIndex} pages → Downloads/AutoSave/`);
      broadcastState();
    }
    return; // skip duplicate frame
  }

  // New page — reset dupe streak
  dupeStreak = 0;
  lastHash   = hash;
  persist();

  // Save
  captureIndex++;
  persist();
  const idx   = String(captureIndex).padStart(4, '0');
  const fname = `${FOLDER}/capture_${idx}_${trigger}_${ts()}.png`;

  try {
    const dlId = await chrome.downloads.download({ url: dataUrl, filename: fname, saveAs: false, conflictAction: 'uniquify' });
    if (dlId < 0) throw new Error('no download id');
  } catch(e) {
    try {
      await chrome.downloads.download({ url: dataUrl, filename: `AutoSave_${idx}_${ts()}.png`, saveAs: false, conflictAction: 'uniquify' });
    } catch(e2) {
      notify('❌ Save Failed', 'Turn OFF "Ask where to save" in Chrome Downloads settings');
      return;
    }
  }

  // Update popup
  chrome.runtime.sendMessage({ type: 'CAPTURED', idx, trigger, captureIndex, autoRunning }).catch(() => {});

  // Badge flash
  chrome.action.setBadgeText({ text: autoRunning ? `${idx}` : '✓' });
  chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
  if (!autoRunning) setTimeout(() => setBadge(), 2500);

  return idx;
}

// ── Helpers ───────────────────────────────────────────────────────────────────
async function getActiveTab() {
  try {
    const wins = await chrome.windows.getAll({ windowTypes: ['normal'] });
    if (!wins.length) return null;
    const win  = wins.find(w => w.focused) || wins[wins.length - 1];
    const tabs = await chrome.tabs.query({ active: true, windowId: win.id });
    return tabs[0] || null;
  } catch(e) { return null; }
}

function isInternal(url) {
  return !url || ['chrome://','chrome-extension://','edge://','about:','devtools://','moz-extension://'].some(p => url.startsWith(p));
}

function ts() {
  const d = new Date(), p = n => String(n).padStart(2,'0');
  return d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'_'+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds());
}

function simpleHash(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h<<5)+h) ^ s.charCodeAt(i);
  return h >>> 0;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function notify(title, msg) {
  try { chrome.notifications.create('apc_'+Date.now(), { type:'basic', iconUrl:'icons/icon48.png', title, message: msg||'', priority:2 }); }
  catch(e) {}
}

function broadcastState() {
  chrome.runtime.sendMessage({ type: 'STATE', enabled: isEnabled, captureIndex, autoRunning }).catch(() => {});
}
