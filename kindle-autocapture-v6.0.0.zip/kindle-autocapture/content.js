// content.js v6.0 — Kindle-compatible auto-advance
// Root cause fix: Kindle Cloud Reader IGNORES dispatchEvent keyboard events.
// It only responds to REAL native mouse clicks on its UI elements.
// Solution: simulate full mousedown+mouseup+click sequence at exact coordinates.

(function () {
  if (window.__apc_v6) return;
  window.__apc_v6 = true;

  var autoTimer   = null;
  var autoRunning = false;
  var slideDelay  = 2000;

  // ── Safe send to background ──────────────────────────────────────────────────
  function send(type, data) {
    try {
      chrome.runtime.sendMessage(
        Object.assign({ type: type }, data || {}),
        function() { void chrome.runtime.lastError; }
      );
    } catch(e) {}
  }

  // ── Full native mouse click simulation ───────────────────────────────────────
  // This is what Kindle actually responds to — a real MouseEvent sequence
  function nativeClick(el, x, y) {
    var cx = (x !== undefined) ? x : (el.getBoundingClientRect ? el.getBoundingClientRect().left + el.offsetWidth/2 : 0);
    var cy = (y !== undefined) ? y : (el.getBoundingClientRect ? el.getBoundingClientRect().top + el.offsetHeight/2 : 0);
    var opts = {
      bubbles: true, cancelable: true, view: window,
      clientX: cx, clientY: cy,
      screenX: cx + window.screenX,
      screenY: cy + window.screenY + (window.outerHeight - window.innerHeight),
      buttons: 1, button: 0
    };
    ['pointerover','pointerenter','mouseover','mouseenter',
     'pointermove','mousemove',
     'pointerdown','mousedown',
     'pointerup','mouseup',
     'click'
    ].forEach(function(t) {
      el.dispatchEvent(new MouseEvent(t, opts));
    });
  }

  // ── Click at a viewport coordinate ──────────────────────────────────────────
  function clickAt(x, y) {
    // Get the topmost element at this position
    var el = document.elementFromPoint(x, y);
    if (!el) el = document.body;
    nativeClick(el, x, y);
  }

  // ── KINDLE-SPECIFIC: find and click the Next Page button ─────────────────────
  function pressNextPage() {
    // Strategy 1: Known Kindle Cloud Reader next-page button selectors
    // (Kindle uses obfuscated class names that change, so we use multiple heuristics)
    var selectors = [
      // Right-side arrow button visible in the UI
      '[class*="kg-next"]',
      '[class*="KGNext"]',
      '[class*="next-page"]',
      '[class*="nextPage"]',
      '[class*="kcrNavigationButton"]:last-of-type',
      '[class*="NavigationButton"]:last-of-type',
      '[data-action="next"]',
      '[aria-label="Next page"]',
      '[aria-label="next page"]',
      '[title="Next page"]',
      '[title="Next"]',
      // Generic right-arrow buttons
      'button[class*="right"]',
      'button[class*="Right"]',
      'div[class*="right"][class*="arrow"]',
      'div[class*="rightArrow"]',
      'div[class*="right-arrow"]',
      // SVG icon buttons
      'button svg[class*="right"]',
    ];

    for (var i = 0; i < selectors.length; i++) {
      var btn = document.querySelector(selectors[i]);
      if (btn && isVisible(btn)) {
        nativeClick(btn);
        send('AUTO_STATUS', { running: true, msg: 'Clicked: ' + selectors[i] });
        return true;
      }
    }

    // Strategy 2: Find all buttons, pick the one in the right-side of screen
    var allBtns = document.querySelectorAll('button, [role="button"], [class*="btn"], [class*="Button"]');
    var rightmost = null, maxX = 0;
    for (var j = 0; j < allBtns.length; j++) {
      var r = allBtns[j].getBoundingClientRect();
      if (r.width < 5 || r.height < 5) continue; // skip hidden
      if (r.left > window.innerWidth * 0.6 && r.left > maxX) {
        maxX = r.left;
        rightmost = allBtns[j];
      }
    }
    if (rightmost) {
      nativeClick(rightmost);
      send('AUTO_STATUS', { running: true, msg: 'Clicked rightmost button' });
      return true;
    }

    // Strategy 3: Check for Kindle iframe — book content may be inside an iframe
    var iframes = document.querySelectorAll('iframe');
    for (var k = 0; k < iframes.length; k++) {
      try {
        var iframeDoc = iframes[k].contentDocument || iframes[k].contentWindow.document;
        if (!iframeDoc) continue;
        // Click right side inside iframe
        var iframeEl = iframeDoc.elementFromPoint(
          iframes[k].offsetWidth * 0.8,
          iframes[k].offsetHeight * 0.5
        );
        if (iframeEl) {
          nativeClick(iframeEl,
            iframes[k].offsetWidth * 0.8,
            iframes[k].offsetHeight * 0.5
          );
          send('AUTO_STATUS', { running: true, msg: 'Clicked inside iframe' });
          return true;
        }
      } catch(e) {} // cross-origin iframe — skip
    }

    // Strategy 4: Tap the right-side of the reading area
    // Kindle advances on click in the right 30% of the viewport
    var tapX = window.innerWidth  * 0.82;
    var tapY = window.innerHeight * 0.50;
    clickAt(tapX, tapY);
    send('AUTO_STATUS', { running: true, msg: 'Tap-to-advance at right side' });
    return true;
  }

  function isVisible(el) {
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.top < window.innerHeight && r.left < window.innerWidth;
  }

  // ── Detect if page actually changed ─────────────────────────────────────────
  // Watch for Kindle page indicator: "Page X of Y" or %
  function getPageIndicator() {
    // Kindle shows "Page 1 of 205 • 0%" at the bottom
    var all = document.querySelectorAll('*');
    for (var i = 0; i < all.length; i++) {
      var t = all[i].innerText || '';
      if (/Page\s+\d+\s+of\s+\d+/.test(t) || /^\d+%$/.test(t.trim())) {
        return t.trim();
      }
    }
    return '';
  }

  // ── AUTO MODE ─────────────────────────────────────────────────────────────────
  function startAuto(delay) {
    if (autoRunning) return;
    autoRunning = true;
    slideDelay  = delay || 2000;
    send('AUTO_STATUS', { running: true, msg: 'Auto started' });

    // Capture current page first
    send('TRIGGER', { trigger: 'auto_p1' });

    function step() {
      if (!autoRunning) return;

      // Click next page
      pressNextPage();

      // Wait for Kindle to render new page, then capture
      setTimeout(function() {
        if (!autoRunning) return;
        send('TRIGGER', { trigger: 'auto' });

        // Schedule next step
        autoTimer = setTimeout(step, slideDelay);
      }, slideDelay);
    }

    // First advance after short pause
    autoTimer = setTimeout(step, 1500);
  }

  function stopAuto() {
    autoRunning = false;
    clearTimeout(autoTimer);
    send('AUTO_STATUS', { running: false, msg: 'Auto stopped' });
  }

  // ── Listen for commands ──────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener(function(msg) {
    if (msg.type === 'START_AUTO') startAuto(msg.delay);
    if (msg.type === 'STOP_AUTO')  stopAuto();
    if (msg.type === 'PING') send('PONG', { autoRunning: autoRunning });
  });

  // ── MANUAL: P key ────────────────────────────────────────────────────────────
  window.addEventListener('keydown', function(e) {
    if ((e.key !== 'p' && e.key !== 'P') || e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;
    if (isTyping()) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    send('TRIGGER', { trigger: 'keyP' });
  }, true);

  // ── MANUAL: Scroll stop ──────────────────────────────────────────────────────
  var scrollTimer = null, baseY = window.scrollY, baseX = window.scrollX;
  window.addEventListener('scroll', function() {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(function() {
      if (Math.abs(window.scrollY-baseY) >= 80 || Math.abs(window.scrollX-baseX) >= 80) {
        baseY = window.scrollY; baseX = window.scrollX;
        send('TRIGGER', { trigger: 'scroll' });
      }
    }, 1200);
  }, { passive: true });

  // ── MANUAL: Arrow / Page keys (when auto is off) ─────────────────────────────
  var SLIDE_KEYS = { ArrowLeft:1, ArrowRight:1, ArrowUp:1, ArrowDown:1, PageUp:1, PageDown:1 };
  var slideTimer = null;
  window.addEventListener('keydown', function(e) {
    if (!SLIDE_KEYS[e.key] || isTyping() || autoRunning) return;
    clearTimeout(slideTimer);
    slideTimer = setTimeout(function() { send('TRIGGER', { trigger: 'slide' }); }, 1200);
  }, { passive: true });

  function isTyping() {
    var el = document.activeElement;
    if (!el) return false;
    var t = el.tagName;
    return t==='INPUT'||t==='TEXTAREA'||t==='SELECT'||el.isContentEditable;
  }

  send('CONTENT_READY', {});
})();
