// ============================================================
//  Auto Page Capture v3.0  —  background.js
//  Triggers: P key, scroll stop, manual
//  Saves:    Downloads/AutoSave/  (flat fallback to Downloads/)
//  Notifications on EVERY step so you see exactly what happens
// ============================================================

const FOLDER     = 'AutoSave';
const MIN_GAP_MS = 1500;   // min time between captures (debounce)

let isEnabled    = true;
let captureIndex = 0;
let lastCapMs    = 0;
let lastHash     = 0;

// ── Restore persisted values on SW wake ──────────────────────────────────────
(async () => {
  const d = await chrome.storage.local.get(['enabled','capIdx','lastHash']);
  isEnabled    = (d.enabled !== false);
  captureIndex = (d.capIdx  || 0);
  lastHash     = (d.lastHash || 0);
  setBadge();
})();

function persist() {
  chrome.storage.local.set({ enabled: isEnabled, capIdx: captureIndex, lastHash });
}

function setBadge() {
  if (isEnabled) {
    chrome.action.setBadgeText({ text: '' });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
  } else {
    chrome.action.setBadgeText({ text: 'OFF' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
  }
}

// ── Show desktop notification ─────────────────────────────────────────────────
function notify(title, msg, id) {
  try {
    chrome.notifications.create(id || ('n' + Date.now()), {
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: title,
      message: msg,
      priority: 2
    });
  } catch(e) {}
}

// ── Message listener ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'TRIGGER') {
    handleTrigger(msg.trigger, sender.tab).then(() => sendResponse({ok:true})).catch(e => {
      notify('❌ Error', e.message);
      sendResponse({ok:false, err: e.message});
    });
    return true; // keep port open for async
  }

  if (msg.type === 'TOGGLE') {
    isEnabled = !isEnabled;
    persist();
    setBadge();
    broadcastState();
    sendResponse({ ok: true, enabled: isEnabled });
    return true;
  }

  if (msg.type === 'GET_STATE') {
    sendResponse({ enabled: isEnabled, captureIndex });
    return true;
  }
});

// ── Handle a capture trigger ──────────────────────────────────────────────────
async function handleTrigger(trigger, senderTab) {
  if (!isEnabled) return;

  // Debounce
  const now = Date.now();
  if (now - lastCapMs < MIN_GAP_MS) return;
  lastCapMs = now;

  // ── STEP 1: Get the tab to capture ─────────────────────────────────────────
  // Use the sender tab directly — it's the tab that sent the message, so it's
  // definitely a real browser tab that's currently visible.
  let tab = senderTab;

  if (!tab || !tab.id) {
    // Fallback: query all normal windows
    try {
      const wins = await chrome.windows.getAll({ windowTypes: ['normal'] });
      if (!wins.length) return notify('❌ No Window', 'No normal browser window found.');
      const win = wins.find(w => w.focused) || wins[wins.length - 1];
      const tabs = await chrome.tabs.query({ active: true, windowId: win.id });
      tab = tabs[0];
    } catch(e) {
      return notify('❌ Tab Error', e.message);
    }
  }

  if (!tab || !tab.id) return notify('❌ No Tab', 'Could not find active tab.');

  const url = tab.url || tab.pendingUrl || '';
  if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://')
           || url.startsWith('edge://')   || url.startsWith('about:')
           || url.startsWith('devtools://')) {
    return; // silently skip internal pages
  }

  // ── STEP 2: Capture the screenshot ─────────────────────────────────────────
  let dataUrl;
  try {
    dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  } catch (e) {
    notify('❌ Capture Failed', e.message);
    return;
  }

  if (!dataUrl || dataUrl.length < 500) {
    notify('❌ Empty Screenshot', 'captureVisibleTab returned empty data.');
    return;
  }

  // ── STEP 3: Duplicate check ─────────────────────────────────────────────────
  const hash = simpleHash(dataUrl.slice(-2000));  // hash last 2000 chars
  if (hash === lastHash) return; // silently skip identical frame
  lastHash = hash;
  persist();

  // ── STEP 4: Build filename and SAVE ─────────────────────────────────────────
  captureIndex++;
  persist();

  const idx  = String(captureIndex).padStart(4, '0');
  const ts   = timestamp();
  const name = 'capture_' + idx + '_' + trigger + '_' + ts + '.png';

  // Try 1: Downloads/AutoSave/filename.png
  let saved = false;
  try {
    const dlId = await chrome.downloads.download({
      url:            dataUrl,
      filename:       FOLDER + '/' + name,
      conflictAction: 'uniquify',
      saveAs:         false
    });
    if (dlId !== undefined && dlId >= 0) {
      saved = true;
      notify('📸 Saved #' + idx, 'Downloads/AutoSave/' + name);
    }
  } catch (e1) {
    // Try 2: flat name in Downloads root (if subfolder blocked)
    try {
      const dlId2 = await chrome.downloads.download({
        url:            dataUrl,
        filename:       'AutoSave_' + name,
        conflictAction: 'uniquify',
        saveAs:         false
      });
      if (dlId2 !== undefined && dlId2 >= 0) {
        saved = true;
        notify('📸 Saved #' + idx, 'Downloads/ AutoSave_' + name + '\n(Subfolder blocked — see popup)');
      }
    } catch (e2) {
      notify('❌ Download Failed', e1.message + ' | ' + e2.message);
      return;
    }
  }

  if (!saved) {
    notify('❌ Download Returned No ID', 'Check Chrome → Settings → Downloads → turn OFF "Ask where to save"');
    return;
  }

  // Broadcast to popup
  chrome.runtime.sendMessage({
    type: 'CAPTURED', idx, trigger, name, captureIndex
  }).catch(() => {});

  // Flash badge
  chrome.action.setBadgeText({ text: '✓' });
  chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
  setTimeout(() => setBadge(), 2000);
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function timestamp() {
  const d = new Date(), p = n => String(n).padStart(2,'0');
  return d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'_'+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds());
}

function simpleHash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) { h = (Math.imul(31, h) + s.charCodeAt(i)) | 0; }
  return h;
}

function broadcastState() {
  chrome.runtime.sendMessage({ type: 'STATE', enabled: isEnabled, captureIndex }).catch(() => {});
}
