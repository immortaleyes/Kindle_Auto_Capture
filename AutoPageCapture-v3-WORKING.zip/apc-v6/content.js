// ============================================================
//  Auto Page Capture v3.0  —  content.js
//  Runs in every Chrome/Edge tab (http/https/file)
//  Sends TRIGGER messages to background.js on:
//    - P key press (not in input fields)
//    - Scroll stop (80px+ movement, debounced 1.2s)
//    - Arrow / PageDown / PageUp keys (slides)
// ============================================================

(function () {
  if (window !== window.top) return;          // top frame only
  if (window.__apc_v3) return;                // don't inject twice
  window.__apc_v3 = true;

  // Check runtime is available before anything
  if (typeof chrome === 'undefined' || !chrome.runtime) return;

  // ── Safe send — wakes SW and passes message ──────────────────────────────
  function send(trigger) {
    try {
      chrome.runtime.sendMessage({ type: 'TRIGGER', trigger }, () => {
        // Ignore chrome.runtime.lastError — SW might log it but it's fine
        void chrome.runtime.lastError;
      });
    } catch (_) {}
  }

  // ── Visual toast — shows bottom-right corner of page ─────────────────────
  let toastEl = null;
  function toast(msg) {
    if (toastEl) toastEl.remove();
    toastEl = document.createElement('div');
    toastEl.textContent = msg;
    const s = toastEl.style;
    s.cssText = [
      'position:fixed', 'bottom:18px', 'right:18px', 'z-index:2147483647',
      'background:rgba(22,163,74,0.95)', 'color:#fff',
      'padding:9px 18px', 'border-radius:10px',
      'font:600 13px/1 system-ui,sans-serif',
      'box-shadow:0 4px 24px rgba(0,0,0,0.35)',
      'opacity:1', 'transition:opacity 0.5s', 'pointer-events:none',
      'letter-spacing:0.2px'
    ].join(';');
    document.documentElement.appendChild(toastEl);
    setTimeout(() => { if(toastEl){ toastEl.style.opacity='0'; } }, 1800);
    setTimeout(() => { if(toastEl){ toastEl.remove(); toastEl=null; } }, 2400);
  }

  // ── Helper: is the user typing in an input? ───────────────────────────────
  function isTyping() {
    const el = document.activeElement;
    if (!el) return false;
    const tag = el.tagName;
    return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT'
        || el.isContentEditable || el.getAttribute('contenteditable') === 'true';
  }

  // ────────────────────────────────────────────────────────────────────────────
  //  TRIGGER 1: Press P key
  // ────────────────────────────────────────────────────────────────────────────
  document.addEventListener('keydown', function(e) {
    // Only plain P — not Ctrl+P (print), not Alt+P, not Meta+P
    if ((e.key !== 'p' && e.key !== 'P') || e.ctrlKey || e.metaKey || e.altKey) return;
    if (isTyping()) return;

    e.preventDefault();   // stop page default for P
    e.stopPropagation();  // stop other handlers
    toast('📸 Saving...');
    send('keyP');
  }, true); // capture phase = highest priority

  // ────────────────────────────────────────────────────────────────────────────
  //  TRIGGER 2: Scroll stop (mouse wheel / touch scroll)
  // ────────────────────────────────────────────────────────────────────────────
  let scrollTimer = null;
  let prevScrollY = window.scrollY;
  let prevScrollX = window.scrollX;

  window.addEventListener('scroll', function () {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(function () {
      const dy = Math.abs(window.scrollY - prevScrollY);
      const dx = Math.abs(window.scrollX - prevScrollX);
      if (dy >= 80 || dx >= 80) {
        prevScrollY = window.scrollY;
        prevScrollX = window.scrollX;
        toast('📸 Auto-saving...');
        send('scroll');
      }
    }, 1200);
  }, { passive: true });

  // ────────────────────────────────────────────────────────────────────────────
  //  TRIGGER 3: Slide navigation keys (PageDown / PageUp / Arrow keys)
  // ────────────────────────────────────────────────────────────────────────────
  const SLIDE_KEYS = new Set(['PageDown','PageUp','ArrowRight','ArrowLeft','ArrowDown','ArrowUp']);
  let slideTimer = null;

  document.addEventListener('keydown', function(e) {
    if (!SLIDE_KEYS.has(e.key)) return;
    if (isTyping()) return;
    clearTimeout(slideTimer);
    slideTimer = setTimeout(function () {
      toast('📸 Slide saved...');
      send('slide');
    }, 600); // wait for slide transition
  }, { passive: true });

})();
